<?php
namespace Pay\Controller;
use Think\Controller;
class IndexController extends Controller {


	public function index()
	{
		echo '22222222222222222';
	}



}