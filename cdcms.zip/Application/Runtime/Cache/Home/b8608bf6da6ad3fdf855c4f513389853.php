<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>增加文章</title>
	<meta charset="UTF-8">
	<link href="/Public/Home/css/normalize.min.css" rel="stylesheet">
	<link href="/Public/Home/css/user.css" rel="stylesheet">
	<link rel="shortcut icon" href="/Public/favicon.ico" type="image/x-icon" />
	<script type="text/javascript" src="/Public/Home/js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="/Public/Home/layer/layer.js"></script>
</head>
<body>
<div class="header">
		<!-- <div class="title-tab">
			<a href="javascript:;"  id="aScstyle" onclick="showBox('aScstyle', 'scstyle');">商城网站</a>
			<a href="javascript:;" <?php echo ($user_classes?'':'class="active"'); ?> id="aYxstyle" onclick="showBox('aYxstyle', 'yxstyle');">营销网站</a>
			<a href="javascript:;"  id="aDomain" onclick="showBox('aDomain', 'domain');">域名</a>
			<a href="javascript:;"  id="aWeigw" onclick="showBox('aWeigw', 'weigw');">微官网</a>
			<a href="javascript:;"  id="aWeifx" onclick="showBox('aWeifx', 'weifx');">微分销</a>
			<a href="javascript:;"  id="aH5" onclick="showBox('aH5', 'h5');">H5宣传页</a>
			<a href="javascript:;"  id="aApp" onclick="showBox('aApp', 'app');">手机app</a>
		</div> -->
		<ul>
			<li>老板 , <?php echo ($date); ?> !</li>
			<li><a href="http://wpa.qq.com/msgrd?v=3&uin=869688800&site=qq&menu=yes" target="_blank" >人工客服</a></li>
			<li><a href="<?php echo U('/Login/logout');?>">退出</a></li>
		</ul>
</div>
<div class="brand">
		<a href="<?php echo U('/Index/index');?>" class="brand"><img src="/Public/Home/images/logo.jpg" alt=""></a>
</div><!-- b头部 -->
 <div class="sidebar">
		<ul class="sidebar-first">
			<li class="active"><a href="<?php echo U('/Index/index');?>">首页</a></li>
			<li><a href="<?php echo U('/Websites/index');?>">我的网站</a></li>
			<li><a href="<?php echo U('/Domains/domains');?>">我的域名</a></li>
			<li><a href="<?php echo U('/Cdservice/cdservice');?>">云狄服务</a></li>
			<li><a href="<?php echo U('/Orders/orders');?>">我的订单</a></li>
			<li><a href="<?php echo U('/Vip/vip');?>">会员中心</a></li>
			<li><a href="<?php echo U('/Carts/carts');?>">购物车</a></li>
		</ul>
</div><!-- 左边栏 -->
 <style> #mynav #nav_a3{background:#006A98;}</style>
  <div class="container">
  <style type="text/css">

#mynav li{

	width:100px;
	height:30px;
	float:left;
	margin-left: 10px;
	line-height: 30px;
	text-align: center;
}
#mynav  a{
	color:#fff;
}

</style>
<div style="width:100%;height:30px;background:#008CBA" id="mynav">
		<ul>
			<li id="nav_a1"><a  href="<?php echo U('Websites/config');?>">网站配置</a></li>
			<li id="nav_a2"><a  href="<?php echo U('Websites/column');?>">栏目管理</a></li>
			<li id="nav_a3"><a  href="<?php echo U('Websites/article');?>">文章管理</a></li>
			<li id="nav_a4"><a  href="<?php echo U('Websites/carousel');?>">轮播图管理</a></li>
			<li id="nav_a5"><a  href="<?php echo U('Websites/friendship');?>">友链管理</a></li>
			<li id="nav_a6"><a  href="<?php echo U('Message/message');?>">留言管理</a></li>
			<li id="nav_a7"><a  href="http://<?php echo session('homeuser.name');?>.<?php echo session('domain');?>"  target="_blank">浏览我的网站</a></li>
		</ul>
</div><!-- 头部 -->
<!-- 百度编辑器 -->
 <script type="text/javascript" charset="utf-8" src="/Public/Home/ueditor-utf8-php/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/Home/ueditor-utf8-php/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="/Public/Home/ueditor-utf8-php/lang/zh-cn/zh-cn.js"></script>
<!-- 百度编辑器 -->

<body topmargin="8">
  <table align="center" border="0" cellpadding="0" cellspacing="0" width="98%">
    <tbody><tr>
      <td height="30" width="60%" style="text-align:left;">
      <a href="<?php echo U('Admin/Article/index',array('cid'=>$cid));?>"><u>文章列表</u></a> &gt;&gt; 发布文章</td>
    </tr>
  </tbody>
  </table>
  <style>
  table{
        width: 100%;
        text-align: none;
      }
      table th, table td{
        padding:0 0;
        text-indent: 0;
      }
      tr{height:40px;}
     td{height:30px;}
     tr:first-child td:first-child{
            text-align:right;
          }
</style>
<form name="form1" action="<?php echo U('Websites/article_add');?>" enctype="multipart/form-data" method="post" onsubmit="return checkSubmit()">
<input type="hidden" name="id" value="<?php echo ($article['article_id']); ?>" id="hidden_id" />
  <table id="needset"  align="center" border="0" cellpadding="2" cellspacing="2" width="98%">
    <tbody>
    <tr style="height:40px;">
      <td colspan="5" class="bline" height="24">
      	<table border="0" cellpadding="0" cellspacing="0" width="800">
          <tbody>
          <tr>
            <td width="35">&nbsp;文章标题：</td>
            <td width="408">
            <input name="article_title" id="title" style="width:70%" type="text" value="<?php echo ($article['article_title']); ?>"/><span style="color:#f00;" id="title_prompt"></span>
            </td>
          </tr>
        </tbody>
        </table>
        </td>
    </tr>
     <tr>
      <td colspan="5" class="bline" height="24">
        <table border="0" cellpadding="0" cellspacing="0" width="800">
        <tbody>
        <tr>
          <td width="38">&nbsp;关键字：</td>
          <td width="448">
          <input name="article_keywords" id="keywords" style="width:70%" type="text" value="<?php echo ($article['article_keywords']); ?>" />
         </td>
        </tr>
      </tbody></table></td>
    </tr>
     <tr>
      <td colspan="5" class="bline" height="24">
      <table border="0" cellpadding="0" cellspacing="0" width="800">
        <tbody>
        <tr>
          <td width="38">&nbsp;文章描述：</td>
          <td width="449"><textarea name="article_description" rows="5" id="description" style="width:70%;height:50px"><?php echo ($article['article_description']); ?></textarea></td>
        </tr>
      </tbody></table>
      </td>
  </tr>
    <tr>
      <td colspan="5" class="bline" height="24">
      	<table border="0" cellpadding="0" cellspacing="0" width="800">
          <tbody>
          <tr>
            
            <td width="90">作　者：</td>
            <td>
            	<input name="article_publisher" id="writer" style="width:70%" type="text" value="<?php echo ($article['article_publisher']); ?>" />
            </td>
              </td>
          </tr>
        </tbody></table>
        </td>
    </tr>
    <tr>
      <td colspan="5" class="bline" height="24">
      	<table border="0" cellpadding="0" cellspacing="0" width="800">
        <tbody><tr>
          <td width="90">&nbsp;所属栏目：</td>
          <td>
       <span id="typeidct">
       <select name="article_column" id="typeid" style="width:240px">
            <option value="0">请选择栏目...</option>
            <?php if(is_array($columns)): foreach($columns as $key=>$v): ?><option value="<?php echo ($v['column_id']); ?>" 
                  <?php if(($v['column_id'] == $article['article_column']) OR ($v['column_id'] == $cid)): ?>selected<?php endif; ?>

              ><?php echo ($v['column_name']); ?></option><?php endforeach; endif; ?>
      </select>
      </span>
			 </td>
        </tr>
      </tbody></table></td>
    </tr>
     <tr>
      <td colspan="5" class="bline" height="24">
        <table border="0" cellpadding="0" cellspacing="0" width="800">
        <tbody><tr>
          <td width="90">&nbsp;文章状态：</td>
          <td>
       <span id="typeidct">
       <input name="article_status" type="radio" value="0"
            <?php if(($article['article_status'] == 0)): ?>checked<?php endif; ?>

       />显示
       <input name="article_status" type="radio" value="1" 
        <?php if(($article['article_status'] == 1)): ?>checked<?php endif; ?>
       />隐藏
      </span>
       </td>
        </tr>
      </tbody></table></td>
    </tr>
  <tr>
     <td colspan="2"><table style="margin-bottom:3px;" border="0" cellpadding="0" cellspacing="0" width="100%">
       <tbody><tr> 
        <td class="bline" height="24" width="90">&nbsp;缩略图：</td>
        <td class="bline">
        <input name="article_pic" id="suoluetu1" style="width:300px" class="text" type="file"  onchange="check(this)"> 
    </td>
       </tr>
    </tbody></table>

<div style="width:280px;height:280px;position:absolute;top:50px;right:20px;<?php echo ($article['article_pic']?'':'display:none;'); ?>" id="div_pic">
     <img src="<?php echo ($article['article_pic']); ?>" width="280" id="imgs">
</div>
</td>
   </tr>
    <tr>
      <td colspan="2" class="bline2" height="28" bgcolor="#F9FCEF">
      	<div style="float:left;line-height:28px;">&nbsp;<strong>文章内容：</strong></div>
      </td>
    </tr>
    <tr>
      <td>
        <script id="editor" type="text/plain" style="width:100%;height:500px;" name="article_text"><?php echo ($article['article_text']); ?></script>
      </td>
    </tr>
    <tr><td><input type="submit" value="提交"></td></tr>
  </tbody>
  </table>
</form>
</div>
</body>
<script type="text/javascript">
var ue = UE.getEditor('editor');//创建百度编辑器
    //获取临时图片
    var img = document.getElementById('imgs');
    function check(obj){
        $('#div_pic').css('display','');
        console.dir(obj.files);
        img.src = window.URL.createObjectURL(obj.files[0]);
    }
    //查询标题是否也存在
    var title_ = false;
  $('#title').change(function(){
    var title = $('#title').val();
    $.post("<?php echo U('Websites/article_title');?>",{'title':title},function(res){
      if(res){
        title_ = false;
        $('#title_prompt').html(res);
      }else{
        title_ = true;
      }
    })
  })

  function checkSubmit(){
    if(!$('#title').val()){
      alert('标题不能为空！');
     return false;
    }else if(!title_ && !$('#hidden_id').val()){
       alert('已有同名文章，请重新填写！');
       return false;
    }else if($('#typeid').val()  == 0){
      alert('你必须选择一个栏目');
      return false;
    }
  }

</script>
</html>