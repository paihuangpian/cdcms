<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>轮播图列表</title>
	<meta charset="UTF-8">
	<link href="/Public/Home/css/normalize.min.css" rel="stylesheet">
	<link href="/Public/Home/css/user.css" rel="stylesheet">
	<link rel="shortcut icon" href="/Public/favicon.ico" type="image/x-icon" />
	<script type="text/javascript" src="/Public/Home/js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="/Public/Home/layer/layer.js"></script>
</head>
<body>
<div class="header">
		<!-- <div class="title-tab">
			<a href="javascript:;"  id="aScstyle" onclick="showBox('aScstyle', 'scstyle');">商城网站</a>
			<a href="javascript:;" <?php echo ($user_classes?'':'class="active"'); ?> id="aYxstyle" onclick="showBox('aYxstyle', 'yxstyle');">营销网站</a>
			<a href="javascript:;"  id="aDomain" onclick="showBox('aDomain', 'domain');">域名</a>
			<a href="javascript:;"  id="aWeigw" onclick="showBox('aWeigw', 'weigw');">微官网</a>
			<a href="javascript:;"  id="aWeifx" onclick="showBox('aWeifx', 'weifx');">微分销</a>
			<a href="javascript:;"  id="aH5" onclick="showBox('aH5', 'h5');">H5宣传页</a>
			<a href="javascript:;"  id="aApp" onclick="showBox('aApp', 'app');">手机app</a>
		</div> -->
		<ul>
			<li>老板 , <?php echo ($date); ?> !</li>
			<li><a href="http://wpa.qq.com/msgrd?v=3&uin=869688800&site=qq&menu=yes" target="_blank" >人工客服</a></li>
			<li><a href="<?php echo U('/Login/logout');?>">退出</a></li>
		</ul>
</div>
<div class="brand">
		<a href="<?php echo U('/Index/index');?>" class="brand"><img src="/Public/Home/images/logo.jpg" alt=""></a>
</div><!-- 头部 -->
<div class="sidebar">
		<ul class="sidebar-first">
			<li class="active"><a href="<?php echo U('/Index/index');?>">首页</a></li>
			<li><a href="<?php echo U('/Websites/index');?>">我的网站</a></li>
			<li><a href="<?php echo U('/Domains/domains');?>">我的域名</a></li>
			<li><a href="<?php echo U('/Cdservice/cdservice');?>">云狄服务</a></li>
			<li><a href="<?php echo U('/Orders/orders');?>">我的订单</a></li>
			<li><a href="<?php echo U('/Vip/vip');?>">会员中心</a></li>
			<li><a href="<?php echo U('/Carts/carts');?>">购物车</a></li>
		</ul>
</div><!-- 左边栏 -->
<div class="container">
<style> #mynav #nav_a4{background:#006A98;}</style>
<style type="text/css">

#mynav li{

	width:100px;
	height:30px;
	float:left;
	margin-left: 10px;
	line-height: 30px;
	text-align: center;
}
#mynav  a{
	color:#fff;
}

</style>
<div style="width:100%;height:30px;background:#008CBA" id="mynav">
		<ul>
			<li id="nav_a1"><a  href="<?php echo U('Websites/config');?>">网站配置</a></li>
			<li id="nav_a2"><a  href="<?php echo U('Websites/column');?>">栏目管理</a></li>
			<li id="nav_a3"><a  href="<?php echo U('Websites/article');?>">文章管理</a></li>
			<li id="nav_a4"><a  href="<?php echo U('Websites/carousel');?>">轮播图管理</a></li>
			<li id="nav_a5"><a  href="<?php echo U('Websites/friendship');?>">友链管理</a></li>
			<li id="nav_a6"><a  href="<?php echo U('Message/message');?>">留言管理</a></li>
			<li id="nav_a7"><a  href="http://<?php echo session('homeuser.name');?>.<?php echo session('domain');?>"  target="_blank">浏览我的网站</a></li>
		</ul>
</div><!-- 头部 -->
<style>
		table{width: 100%;text-align: none;background-color: #C3C3C3; }
      	table th, table td{ padding:0 0; text-indent: 0; }
     	td{height:20px;}
      	a{text-decoration:none;}
</style>
<!--  内容列表   -->
<table width="98%" border="0" cellpadding="2" cellspacing="1" bgcolor="#D1DDAA" align="center" style="margin-top:8px">
<tr bgcolor="#E7E7E7" >
	<td colspan="10">&nbsp;轮播图列表&nbsp;
	<a href="<?php echo U('Websites/carousel_add');?>">添加轮播图</a>
	</td>
</tr>
<tr align="center" bgcolor="#FAFAF1" height="22">
	<td width="6%">ID</td>
	<td width="4%">选择</td>
	<td width="28%">轮播图名称</td>
	<td width="28%">图片</td>
	<td width="10%">录入时间</td>
	<td width="8%">权限</td>
	<td width="10%">操作</td>
</tr>
<?php if(is_array($carousels)): foreach($carousels as $key=>$v): ?><tr align='center' bgcolor="#FFFFFF" height="22" id="delete<?php echo ($v['carousel_id']); ?>"  >
		<td><?php echo ($v['carousel_id']); ?></td>
		<td><input name="id" type="checkbox" id="id" value="<?php echo ($v['carousel_id']); ?>" class="np"></td>
		<td align="left"><?php echo ($v['carousel_name']); ?></td>
		<td style="width:320px;height:90px;">
		<a href=''>
		<img src="<?php echo ($v['carousel_pic']); ?>"  style="max-height:90px;max-width:320px;"></a></td>
		<td><?php echo ($v['carousel_addtime']); ?></td>
		<td><?php echo ($v['carousel_status']); ?></td>
		<td><a href="<?php echo U('Websites/carousel_add',array('id'=>$v['carousel_id']));?>">编辑</a> |
		<a href="javascript:;" onclick="deletes(<?php echo ($v['carousel_id']); ?>)">删除</a>
		</td>
	</tr><?php endforeach; endif; ?>
<tr bgcolor="#FAFAF1">
<td height="28" colspan="10">
	&nbsp;
	<a href="javascript:selAll()"  class="coolbg">全选</a>
	 <a href="javascript:noSelAll()" class="coolbg">取消</a>
	<a href="javascript:delArc()" class="coolbg">&nbsp;删除&nbsp;</a>
</td>
</tr>
<style type="text/css">
	.tcdPageCode li{
		display:inline;
		width:30px;
		height:25px;
		font-size:20px;
		margin-left: 10px;
	}
	.current{

		font-size:22px;
		color:#f00;
	}
</style>
<tr align="right" bgcolor="#EEF4EA">
	<td height="36" colspan="10" align="center" >
	<div class="tcdPageCode">
			<ul>
				<?php echo ($show); ?>
				<li style="font-size:15px;">共<?php echo ($number); ?>页 <font style="font-size:30px;">.</font><?php echo ($count); ?>条结果</li>
			</ul>
	</div>
	</td>
</tr>
</table>
</div>
<script type="text/javascript">
	 $(function (){
        $('.tcdPageCode ul div a').unwrap('div').wrapInner('<li></li>');
        $('.tcdPageCode ul span').wrap('<li class="active"></li>');
    })
</script>
</body>
<script type="text/javascript">
//删除文章
function deletes(id)
{
    if(confirm('你确认要删除吗！')){
     $.post("<?php echo U('Websites/carousel_delete');?>",{'id':id},function(res){
        if(res == 1){
            $('#delete' + id).remove();
            layer.msg('删除成功', {icon: 6});
        }else{

          layer.msg(res, {icon: 5});
        }
     })
    }
}
//全选
function selAll(){
	$(":checkbox").attr('checked',true);
}
//取消全选
function noSelAll(){
	$(":checkbox").attr('checked',false);
}

//批量删除

function delArc(){
			if($("input:checked").length <= 0){
				alert('你没有选择任何文章！');
				return;
			}
			if(confirm('批量操作，小心谨慎！你确定删除吗？')){

					var check = $("input:checked");
					var arr = {};
					for(var i = 0;i < check.length;i++){
						arr[i] = check.eq(i).val(); 
					}
					$.post("<?php echo U('Websites/carousel_delarc');?>",{'arr':arr},function(res){
						if(res == 1){
							for(var j = check.length;j >= 0;j--){
				           		 $('#delete' + check.eq(j).val()).remove();
							}
				            layer.msg('批量删除成功', {icon: 6});
				        }else{
				            layer.msg(res, {icon: 5});
				        }
					})
			}
}
</script>
</html>