<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>栏目管理</title>
  	<meta charset="UTF-8">
	<link href="/Public/Home/css/normalize.min.css" rel="stylesheet">
	<link href="/Public/Home/css/user.css" rel="stylesheet">
	<link rel="shortcut icon" href="/Public/favicon.ico" type="image/x-icon" />
	<script type="text/javascript" src="/Public/Home/js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="/Public/Home/layer/layer.js"></script>
</head>
<body>
<div class="header">
		<div class="title-tab">
			<a href="javascript:;"  id="aScstyle" onclick="showBox('aScstyle', 'scstyle');">商城网站</a>
			<a href="javascript:;" <?php echo ($user_classes?'':'class="active"'); ?> id="aYxstyle" onclick="showBox('aYxstyle', 'yxstyle');">营销网站</a>
			<a href="javascript:;"  id="aDomain" onclick="showBox('aDomain', 'domain');">域名</a>
			<a href="javascript:;"  id="aWeigw" onclick="showBox('aWeigw', 'weigw');">微官网</a>
			<a href="javascript:;"  id="aWeifx" onclick="showBox('aWeifx', 'weifx');">微分销</a>
			<a href="javascript:;"  id="aH5" onclick="showBox('aH5', 'h5');">H5宣传页</a>
			<a href="javascript:;"  id="aApp" onclick="showBox('aApp', 'app');">手机app</a>
		</div>
		<ul>
			<li>老板 , <?php echo ($date); ?> !</li>
			<li><a href="http://wpa.qq.com/msgrd?v=3&uin=869688800&site=qq&menu=yes" target="_blank" >人工客服</a></li>
			<li><a href="<?php echo U('/Login/logout');?>">退出</a></li>
		</ul>
</div>
<div class="brand">
		<a href="<?php echo U('/Index/index');?>" class="brand"><img src="/Public/Home/images/logo.jpg" alt=""></a>
</div><!-- 左边栏 -->
<script type="text/javascript" src="/Public/Home/layer/layer.js"></script>
  <style type="text/css">
      table{
        width: 100%;
        text-align: none;
        background-color: #C3C3C3;
      }
      table th, table td{
        padding:0 0;
        border: none;
        text-indent: 0;
      }
      tr{
        height:10px;
      }
      .zf_table{
        background: #fff;
      }
      .container{
        z-index: 0;
      }

  </style>
  <div class="sidebar">
		<ul class="sidebar-first">
			<li class="active"><a href="<?php echo U('/Index/index');?>">首页</a></li>
			<li><a href="<?php echo U('/Websites/index');?>">我的网站</a></li>
			<li><a href="<?php echo U('/Domains/domains');?>">我的域名</a></li>
			<li><a href="<?php echo U('/Cdservice/cdservice');?>">云狄服务</a></li>
			<li><a href="<?php echo U('/Orders/orders');?>">我的订单</a></li>
			<li><a href="<?php echo U('/Vip/vip');?>">会员中心</a></li>
			<li><a href="<?php echo U('/Carts/carts');?>">购物车</a></li>
		</ul>
</div><!-- 左边栏 -->
  <div class="container">
  <style type="text/css">

#mynav li{

	width:100px;
	height:30px;
	float:left;
	margin-left: 10px;
	line-height: 30px;
}
#mynav li a{
	color:#fff;
}
</style>
<div style="width:100%;height:30px;background:#008CBA" id="mynav">
		<ul>
			<li><a href="<?php echo U('Websites/config');?>">网站配置</a></li>
			<li><a href="<?php echo U('Websites/column');?>">栏目管理</a></li>
			<li><a href="<?php echo U('Websites/article');?>">文章管理</a></li>
			<li><a href="<?php echo U('Websites/carousel');?>">轮播图管理</a></li>
			<li><a href="<?php echo U('Websites/friendship');?>">友链管理</a></li>
		</ul>
</div><!-- 头部 -->
  
<table align="center" bgcolor="#cfcfcf" border="0" cellpadding="3" cellspacing="1" width="98%">
<tbody>
<tr style="background:#fff;">
   <td style="padding-left:10px;" height="28" >
   <div style="float:left">
    	<strong>网站栏目管理 </strong>
   </div>
   <div style="float:right;padding-right:6px;">
   	<a href="<?php echo U('/Websites/column_add');?>" class="np coolbg" >增加顶级栏目</a>
   </div></td>
</tr>
<form name="form1" method="post" action="catalog_do.php?dopost=upRankAll"></form>
<tr>
<td height="120" bgcolor="#FFFFFF" valign="top" >
<?php if(is_array($columns)): foreach($columns as $key=>$vo): ?><table border="0" cellpadding="2" cellspacing="0" class="zf_table" width="100%" id="table<?php echo ($vo['column_id']); ?>">
      <tbody>
      <tr>
      <td style="background-color:#FBFCE2;" class="bline" width="2%">
      <img style="cursor:pointer" id="img<?php echo ($vo['column_id']); ?>" onclick="LoadSunss(<?php echo ($vo['column_id']); ?>); " src="/Public/Home/column/dedeexplode.gif" height="11" width="11">
      </td>
      <td style="background-color:#FBFCE2;" class="bline">
      <table border="0" cellpadding="0" cellspacing="0" width="98%"><tbody><tr><td width="50%">
      <input class="np" name="tids[]" value="26" type="checkbox">
      <a href="<?php echo U('/Websites/article',array('cid'=>$vo['column_id']));?>">
      <font color="red"></font><?php echo ($vo['column_name']); ?>[ID:<?php echo ($vo['column_id']); ?>]</a>(文档：<?php echo ($vo[ $vo['column_id'] ]); ?>)  
      </td>
      <td align="right"><a href="<?php echo U('Home/Index/index');?>" target="_blank">预览</a>|
      <a href="<?php echo U('/Websites/article',array('cid'=>$vo['column_id']));?>">内容</a>|
      <a href="<?php echo U('/Websites/column_add',array('pid'=>$vo['column_id']));?>">增加子类</a>|
      <a href="<?php echo U('/Websites/column_modify',array('id'=>$vo['column_id']));?>">更改</a>|
      <a href="javascript:;" onclick="deletes(<?php echo ($vo['column_id']); ?>)" style="margin-right:50px;">删除</a>&nbsp;
      <!--  <input name="sortrank26" value="50" style="width:25px;height:20px" type="text"> -->
      <?php $status = array('正常','隐藏');?>
      <button id="but<?php echo ($vo['column_id']); ?>" prompt="<?php echo ($vo['column_status']); ?>" onclick="status(<?php echo ($vo['column_id']); ?>);"><?php echo $status[ $vo['column_status']];?></button>

      </td></tr></tbody></table></td></tr>
      <tr><td colspan="2" id="suns26"></td></tr>
    </tbody></table>
<div style="margin-left:10px;display:none;" id="loads<?php echo ($vo['column_id']); ?>" judge='1'>

</div><?php endforeach; endif; ?>
<br>
</td>
</tr>
</tbody>
</table>
</div>
<script type="text/javascript">
//异步加载栏目
function LoadSunss(id)
{
    if($('#loads' + id).attr('judge') == 2){
      $('#loads' + id).css('display','none');
      $('#img' + id).attr('src',"/Public/Home/column/dedeexplode.gif");
       $('#loads' + id).attr('judge',1);
      return;
    }
      $('#loads' + id).css('display','');
      $('#img' + id).attr('src',"/Public/Home/column/dedecontract.gif");

      $('#loads' + id).load("<?php echo U('Websites/column2');?>",{pid: id},function(){

        $('#loads' + id).attr('judge',2);
      })
}

//删除栏目
function deletes(ids)
{
    if(confirm('你确认要删除吗！')){
     $.post("<?php echo U('Websites/column_delete');?>",{'id':ids},function(res){
        if(res == 1){
            $('#table' + ids).remove();
            layer.msg('删除成功', {icon: 6});
        }else{
          layer.msg(res, {icon: 5});
        }
     })
    }
}

function status(id){
  var column_status = $('#but' + id).attr('prompt');
  $.post("<?php echo U('Websites/column_status');?>",{'id':id,'status':column_status},function(res){
      if(res == 1){
         $('#but' + id).html('隐藏');
         $('#but' + id).attr('prompt',res);
         layer.msg('已隐藏', {icon: 6});
      }else if(res == 0){

         $('#but' + id).html('正常');
         $('#but' + id).attr('prompt',res);
         layer.msg('已恢复正常', {icon: 6});
      }else{
        layer.msg('失败了，稍后再试！', {icon: 5});
      }
  })
}
</script>
</body>
</html>