<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
<title>增加友情链接</title>
	<meta charset="UTF-8">
	<link href="/Public/Home/css/normalize.min.css" rel="stylesheet">
	<link href="/Public/Home/css/user.css" rel="stylesheet">
	<link rel="shortcut icon" href="/Public/favicon.ico" type="image/x-icon" />
	<script type="text/javascript" src="/Public/Home/js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="/Public/Home/layer/layer.js"></script>
</head>
<body>
<div class="header">
		<div class="title-tab">
			<a href="javascript:;"  id="aScstyle" onclick="showBox('aScstyle', 'scstyle');">商城网站</a>
			<a href="javascript:;" <?php echo ($user_classes?'':'class="active"'); ?> id="aYxstyle" onclick="showBox('aYxstyle', 'yxstyle');">营销网站</a>
			<a href="javascript:;"  id="aDomain" onclick="showBox('aDomain', 'domain');">域名</a>
			<a href="javascript:;"  id="aWeigw" onclick="showBox('aWeigw', 'weigw');">微官网</a>
			<a href="javascript:;"  id="aWeifx" onclick="showBox('aWeifx', 'weifx');">微分销</a>
			<a href="javascript:;"  id="aH5" onclick="showBox('aH5', 'h5');">H5宣传页</a>
			<a href="javascript:;"  id="aApp" onclick="showBox('aApp', 'app');">手机app</a>
		</div>
		<ul>
			<li>老板 , <?php echo ($date); ?> !</li>
			<li><a href="http://wpa.qq.com/msgrd?v=3&uin=869688800&site=qq&menu=yes" target="_blank" >人工客服</a></li>
			<li><a href="<?php echo U('/Login/logout');?>">退出</a></li>
		</ul>
</div>
<div class="brand">
		<a href="<?php echo U('/Index/index');?>" class="brand"><img src="/Public/Home/images/logo.jpg" alt=""></a>
</div><!-- b头部 -->
<div class="sidebar">
		<ul class="sidebar-first">
			<li class="active"><a href="<?php echo U('/Index/index');?>">首页</a></li>
			<li><a href="<?php echo U('/Websites/index');?>">我的网站</a></li>
			<li><a href="<?php echo U('/Domains/domains');?>">我的域名</a></li>
			<li><a href="<?php echo U('/Cdservice/cdservice');?>">云狄服务</a></li>
			<li><a href="<?php echo U('/Orders/orders');?>">我的订单</a></li>
			<li><a href="<?php echo U('/Vip/vip');?>">会员中心</a></li>
			<li><a href="<?php echo U('/Carts/carts');?>">购物车</a></li>
		</ul>
</div><!-- 左边栏 -->
<div class="container">
<style type="text/css">

#mynav li{

	width:100px;
	height:30px;
	float:left;
	margin-left: 10px;
	line-height: 30px;
}
#mynav li a{
	color:#fff;
}
</style>
<div style="width:100%;height:30px;background:#008CBA" id="mynav">
		<ul>
			<li><a href="<?php echo U('Websites/config');?>">网站配置</a></li>
			<li><a href="<?php echo U('Websites/column');?>">栏目管理</a></li>
			<li><a href="<?php echo U('Websites/article');?>">文章管理</a></li>
			<li><a href="<?php echo U('Websites/carousel');?>">轮播图管理</a></li>
			<li><a href="<?php echo U('Websites/friendship');?>">友链管理</a></li>
			<li><a href="<?php echo U('Message/message');?>">留言管理</a></li>
		</ul>
</div><!-- 头部 -->
    <style>
    table{ width: 100%; text-align: none;}
      table th, table td{ padding:0 0; text-indent: 0; }
      td{height:10px;}
      tr:first-child td:first-child{ text-align:right;}
    </style>
  <table align="center" border="0" cellpadding="0" cellspacing="0" width="98%">
    <tbody><tr>
      <td height="30" width="60%" style="text-align:left;">
      <a href="<?php echo U('Websites/friendship',array('cid'=>$cid));?>">友情链接列表</a> &gt;&gt; 添加轮播图</td>
    </tr>
  </tbody>
  </table>
<form name="form1" action="<?php echo U('Websites/friendship_add');?>?id=<?php echo ($friendship['friendship_id']); ?>" enctype="multipart/form-data" method="post" onsubmit="return checkSubmit()">
  <table id="needset" style="border:1px solid #cfcfcf;background:#ffffff;" align="center" border="0" cellpadding="2" cellspacing="2" width="98%">
    <tbody>
    <tr>
      <td colspan="5" class="bline" height="24">
      	<table border="0" cellpadding="0" cellspacing="0" width="800">
          <tbody><tr>
            <td width="76">&nbsp;友情链接名称：</td>
            <td width="408"><input name="friendship_name" id="title" style="width:588px" value="<?php echo ($friendship['friendship_name']); ?>" type="text" /></td>
          </tr>
        </tbody></table></td>
    </tr>
     <tr>
      <td colspan="5" class="bline" height="24">
        <table border="0" cellpadding="0" cellspacing="0" width="800">
          <tbody><tr>
            <td width="76">&nbsp;连接地址：</td>
            <td width="408"><input name="friendship_url" style="width:588px" value="<?php echo ($friendship['friendship_url']); ?>" type="text" /></td>
          </tr>
        </tbody></table></td>
    </tr>
     <tr>
      <td colspan="5" class="bline" height="24">
        <table border="0" cellpadding="0" cellspacing="0" width="800">
          <tbody><tr>
            <td width="76">&nbsp;站长邮箱：</td>
            <td width="408"><input name="friendship_email" style="width:588px" value="<?php echo ($friendship['friendship_email']); ?>" type="text" /></td>
          </tr>
        </tbody></table></td>
    </tr>
     <tr>
      <td colspan="5" class="bline" height="24">
        <table border="0" cellpadding="0" cellspacing="0" width="800">
          <tbody><tr>
            <td width="76">&nbsp;备注：</td>
            <td width="408"><input name="friendship_remarks" style="width:588px" value="<?php echo ($friendship['friendship_remarks']); ?>" type="text" /></td>
          </tr>
        </tbody></table></td>
    </tr>
     <tr>
      <td colspan="5" class="bline" height="24">
        <table border="0" cellpadding="0" cellspacing="0" width="800">
        <tbody>
        <tr>
          <td width="130">&nbsp;状态：</td>
          <td>
       <span id="typeidct">
       <input name="friendship_status" type="radio" value="0" checked />显示
       <input name="friendship_status" type="radio" value="1" <?php echo ($friendship['friendship_status']?'checked':''); ?> />隐藏
      </span>
       </td>
        </tr>
      </tbody></table></td>
    </tr>
  <tr>
     <td colspan="2"><table style="margin-bottom:3px;" border="0" cellpadding="0" cellspacing="0" width="100%">
       <tbody><tr> 
        <td class="bline" height="24" width="130">&nbsp;图片：</td>
        <td class="bline">
        <input name="friendship_logo" id="suoluetu1" style="width:300px" class="text" type="file"  onchange="check(this)"> 
    </td>
       </tr>
    </tbody></table>
</td>
   </tr>
    <tr>
    <td></td>
    <td>
    <span style="margin-left:130px;color:#f00;"><?php echo ((isset($_GET['error']) && ($_GET['error'] !== ""))?($_GET['error']):''); ?></span>
      <input type="submit" value="提交">
    </td>
    </tr>
  </tbody>
  </table>
</form>
<div style="width:98%;text-align:center;" id="div_pic">
     <img src="<?php echo ($friendship['friendship_logo']); ?>" style="max-width:98%" id="imgs">
</div>
</div>
</body>
<script type="text/javascript">
    //获取临时图片
    var img = document.getElementById('imgs');
    function check(obj){
        $('#div_pic').css('display','');
        console.dir(obj.files);
        img.src = window.URL.createObjectURL(obj.files[0]);
    }
</script>
</html>