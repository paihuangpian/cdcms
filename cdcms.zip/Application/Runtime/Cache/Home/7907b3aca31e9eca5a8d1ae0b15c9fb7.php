<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
<title>文档管理</title>
	<meta charset="UTF-8">
	<link href="/Public/Home/css/normalize.min.css" rel="stylesheet">
	<link href="/Public/Home/css/user.css" rel="stylesheet">
	<link rel="shortcut icon" href="/Public/favicon.ico" type="image/x-icon" />
	<script type="text/javascript" src="/Public/Home/js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="/Public/Home/layer/layer.js"></script>
</head>
<body>
<div class="header">
		<div class="title-tab">
			<a href="javascript:;"  id="aScstyle" onclick="showBox('aScstyle', 'scstyle');">商城网站</a>
			<a href="javascript:;" <?php echo ($user_classes?'':'class="active"'); ?> id="aYxstyle" onclick="showBox('aYxstyle', 'yxstyle');">营销网站</a>
			<a href="javascript:;"  id="aDomain" onclick="showBox('aDomain', 'domain');">域名</a>
			<a href="javascript:;"  id="aWeigw" onclick="showBox('aWeigw', 'weigw');">微官网</a>
			<a href="javascript:;"  id="aWeifx" onclick="showBox('aWeifx', 'weifx');">微分销</a>
			<a href="javascript:;"  id="aH5" onclick="showBox('aH5', 'h5');">H5宣传页</a>
			<a href="javascript:;"  id="aApp" onclick="showBox('aApp', 'app');">手机app</a>
		</div>
		<ul>
			<li>老板 , <?php echo ($date); ?> !</li>
			<li><a href="http://wpa.qq.com/msgrd?v=3&uin=869688800&site=qq&menu=yes" target="_blank" >人工客服</a></li>
			<li><a href="<?php echo U('/Login/logout');?>">退出</a></li>
		</ul>
</div>
<div class="brand">
		<a href="<?php echo U('/Index/index');?>" class="brand"><img src="/Public/Home/images/logo.jpg" alt=""></a>
</div><!-- b头部 -->
<div class="sidebar">
		<ul class="sidebar-first">
			<li class="active"><a href="<?php echo U('/Index/index');?>">首页</a></li>
			<li><a href="<?php echo U('/Websites/index');?>">我的网站</a></li>
			<li><a href="<?php echo U('/Domains/domains');?>">我的域名</a></li>
			<li><a href="<?php echo U('/Cdservice/cdservice');?>">云狄服务</a></li>
			<li><a href="<?php echo U('/Orders/orders');?>">我的订单</a></li>
			<li><a href="<?php echo U('/Vip/vip');?>">会员中心</a></li>
			<li><a href="<?php echo U('/Carts/carts');?>">购物车</a></li>
		</ul>
</div><!-- 左边栏 -->
<div class="container">
<style type="text/css">

#mynav li{

	width:100px;
	height:30px;
	float:left;
	margin-left: 10px;
	line-height: 30px;
}
#mynav li a{
	color:#fff;
}
</style>
<div style="width:100%;height:30px;background:#008CBA" id="mynav">
		<ul>
			<li><a href="<?php echo U('Websites/config');?>">网站配置</a></li>
			<li><a href="<?php echo U('Websites/column');?>">栏目管理</a></li>
			<li><a href="<?php echo U('Websites/article');?>">文章管理</a></li>
			<li><a href="<?php echo U('Websites/carousel');?>">轮播图管理</a></li>
			<li><a href="<?php echo U('Websites/friendship');?>">友链管理</a></li>
		</ul>
</div><!-- 头部 -->
<!--  快速转换位置按钮  -->
<style>
		table{ width: 100%; text-align: none; background-color: #C3C3C3; }
     	table th, table td{ padding:0 0; text-indent: 0; }
     	td{height:10px;}
</style>

<!--  内容列表   -->
<form name="form2">
<table width="98%" border="0" cellpadding="2" cellspacing="1" bgcolor="#D1DDAA" align="center" style="margin-top:8px">
<tr bgcolor="#E7E7E7">
	<td height="24" colspan="10" background="/Public/Home/column/tbg.gif">&nbsp;文档列表&nbsp;
	<a href="<?php echo U('Websites/article_add',array('cid'=>$cid));?>">添加文章</a>
	</td>
</tr>
<tr align="center" bgcolor="#FAFAF1" height="22">
	<td width="6%">ID</td>
	<td width="4%">选择</td>
	<td width="28%">文章标题</td>
	<td width="10%">录入时间</td>
	<td width="10%">类目</td>
	<td width="8%">点击</td>
	<td width="8%">权限</td>
	<td width="8%">发布人</td>
	<td width="15%">操作</td>
</tr>
<?php if(is_array($articles)): foreach($articles as $key=>$v): ?><tr align='center' bgcolor="#FFFFFF" height="22" id="delete<?php echo ($v['article_id']); ?>" >
		<td><?php echo ($v['article_id']); ?></td>
		<td><input name="id" type="checkbox" id="id" value="<?php echo ($v['article_id']); ?>" class="np"></td>
		<td align="left"><a href=''><u><?php echo ($v['article_title']); ?></u></a></td>
		<td><?php echo ($v['article_time']); ?></td>
		<td id="td<?php echo ($v['article_id']); ?>"><?php echo ($v['article_column']); ?></td>
		<td><?php echo ($v['article_clicks']); ?></td>
		<td><?php echo ($v['article_status']); ?></td>
		<td><?php echo ($v['article_publisher']); ?></td>
		<td><a href="<?php echo U('Websites/article_add',array('id'=>$v['article_id']));?>">编辑</a> |
		<a href="<?php echo ($domainurl); ?>/Indexs/product?aid=<?php echo ($v['article_id']); ?>" target="_blank">预览</a> | 
		<a href="javascript:;" onclick="deletes(<?php echo ($v['article_id']); ?>)">删除</a>
		</td>
	</tr><?php endforeach; endif; ?>

<tr bgcolor="#FAFAF1">
<td height="28" colspan="10">
	&nbsp;
	<a href="javascript:selAll()"  class="coolbg">全选</a>
	 <a href="javascript:noSelAll()" class="coolbg">取消</a>
	<a href="javascript:shows()" class="coolbg">&nbsp;移动&nbsp;</a>
	<a href="javascript:delArc()" class="coolbg">&nbsp;删除&nbsp;</a>
</td>
</tr>
<style type="text/css">

	.tcdPageCode li{
		display:inline;
		width:35px;
		height:25px;
		font-size:20px;
		margin-left: 10px;
		/*background: #f00;*/
	}
	.current{

		font-size:22px;
		color:#f00;
	}

</style>
<tr align="right" bgcolor="#EEF4EA">
	<td height="36" colspan="10" align="center" >
	<div class="tcdPageCode">
			<ul>
				<?php echo ($show); ?>
				<li style="font-size:15px;width:120px;">共<?php echo ($number); ?>页 <font style="font-size:30px;">.</font><?php echo ($count); ?>条结果</li>

			</ul>
	</div>
	</td>
</tr>
</table>
</form>
<script type="text/javascript">
	 $(function (){
        $('.tcdPageCode ul div a').unwrap('div').wrapInner('<li></li>');
        $('.tcdPageCode ul span').wrap('<li class="active"></li>');
    })
</script>
<!--  搜索表单  -->
<form name='form3' action="<?php echo U('Websites/article_search');?>" method='post'>
<input type='hidden' name='dopost' value='' />
<table width='98%'  border='0' cellpadding='1' cellspacing='1' bgcolor='#CBD8AC' align="center" style="margin-top:8px">
  <tr bgcolor='#EEF4EA'>
    <td background='/Public/Home/column/tbg.gif' align='center'>
      <table border='0' cellpadding='0' cellspacing='0'>
        <tr>
          <td width='90' align='center'>搜索条件：</td>
          <td width='160'>
          <select name='conditions' style='width:150px;'>
          	<option value='1'>文章标题</option>
          	<option value='2'>关键字</option>
          	<option value='3'>文章内容</option>
          </select>
        </td>
        <td width='70'>
          关键字：
        </td>
        <td width='160'>
          	<input type='text' name='keywords' value='' style='width:150px' />
        </td>
        <td width='110'>
    		<select name='orderby' style='width:150px'>
            <option value='id'>排序...</option>
            <option value='pubdate'>发布时间</option>
      	</select>
        </td>
        <td>
          <input name="imageField" type="submit"  width="45" height="20" border="0" class="np" value="搜索" />
        </td>
       </tr>
      </table>
    </td>
  </tr>
</table>
</form>

<!-- 更改文章栏目模态框 -->
<style type="text/css">
  #div{
        width:350px;
        height:100px;
        background: #036542;
        position:fixed;
        top:25%;
        left:35%;
        z-index:99;
  }
</style>
<div id="div" style="display:none;">
  <button style="float:right;margin-right:5px;margin-top:5px;" id="but">X</button>
<br><br>
      <div class="input"> <span style="margin-left:5px;">移动到：</span> 
      	<select name="article_column" id="selects">
	      	<?php if(is_array($columns)): foreach($columns as $key=>$v): ?><option value="<?php echo ($v['column_id']); ?>"><?php echo ($v['column_name']); ?></option><?php endforeach; endif; ?>
      	</select>
      	<button type="button" onclick="moveArc()" >移动</button>
      </div>
</div>
</div>
<div style="width:100%;height:100%;position:absolute;left:0;top:0;z-index:9;display:none;background-color: hsla(100,20%,50%,0.5);" id="div2"></div>
</body>
<script type="text/javascript">
//显示模态框  移动时
function shows(){
			if($("input:checked").length <= 0){
				alert('你没有选择任何文章！');
				return;
			}
	          $("#div2").css('display','');
	          $("#div2").css('height',$('html').height());
	          $('#div').show(300);
} 
 //隐藏模态框
 $('#but').click(function(){
  $("#div2").css('display','none');
  $('#div').hide(300);
 })


//删除文章
function deletes(id)
{
    if(confirm('你确认要删除吗！')){
     $.post("<?php echo U('Websites/article_delete');?>",{'id':id},function(res){
        if(res == 1){
            $('#delete' + id).remove();
            layer.msg('删除成功', {icon: 6});
        }else{
          layer.msg(res, {icon: 5});
        }
     })
      
    }
}



//全选
function selAll(){

	$(":checkbox").attr('checked',true);
}

//取消全选
function noSelAll(){

	$(":checkbox").attr('checked',false);

}

//批量删除
function delArc(){
			if($("input:checked").length <= 0){
				alert('你没有选择任何文章！');
				return;
			}
			if(confirm('批量操作，小心谨慎！你确定删除吗？')){

					var check = $("input:checked");
					var arr = {};
					for(var i = 0;i < check.length;i++){
						arr[i] = check.eq(i).val(); 
					}
					$.post("<?php echo U('Websites/article_delarc');?>",{'arr':arr},function(res){
						if(res == 1){
							for(var j = check.length;j >= 0;j--){
				           		 $('#delete' + check.eq(j).val()).remove();
							}
				            layer.msg('批量删除成功', {icon: 6});
				        }else{
				            layer.msg(res, {icon: 5});
				        }
					})
			}
}

//移动文章
function moveArc(){
					var column_id = $('#selects').val();
					var check = $("input:checked");
					var arr = {};
					for(var i = 0;i < check.length;i++){
						arr[i] = check.eq(i).val(); 
					}
					$.post("<?php echo U('Websites/article_moveArc');?>",{'arr':arr,'column_id':column_id},function(res){
						if(res){
							 $("#div2").css('display','none');
  							 $('#div').hide(300);
  							 for(var j = check.length;j >= 0;j--){
				           		 $('#td' + check.eq(j).val()).html($("select option:selected").eq(2).html());
							}
							$(":checkbox").attr('checked',false);
							layer.msg('移动栏目成功', {icon: 6});
						}else{
								layer.msg(res, {icon: 5});
						}
					})
}
</script>
</html>