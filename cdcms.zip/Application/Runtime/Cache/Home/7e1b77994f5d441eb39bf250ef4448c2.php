<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<title>用户首页</title>
		<meta charset="UTF-8">
	<link href="/Public/Home/css/normalize.min.css" rel="stylesheet">
	<link href="/Public/Home/css/user.css" rel="stylesheet">
	<link rel="shortcut icon" href="/Public/favicon.ico" type="image/x-icon" />
	<script type="text/javascript" src="/Public/Home/js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="/Public/Home/layer/layer.js"></script>
</head>
<body>
<div class="header">
		<!-- <div class="title-tab">
			<a href="javascript:;"  id="aScstyle" onclick="showBox('aScstyle', 'scstyle');">商城网站</a>
			<a href="javascript:;" <?php echo ($user_classes?'':'class="active"'); ?> id="aYxstyle" onclick="showBox('aYxstyle', 'yxstyle');">营销网站</a>
			<a href="javascript:;"  id="aDomain" onclick="showBox('aDomain', 'domain');">域名</a>
			<a href="javascript:;"  id="aWeigw" onclick="showBox('aWeigw', 'weigw');">微官网</a>
			<a href="javascript:;"  id="aWeifx" onclick="showBox('aWeifx', 'weifx');">微分销</a>
			<a href="javascript:;"  id="aH5" onclick="showBox('aH5', 'h5');">H5宣传页</a>
			<a href="javascript:;"  id="aApp" onclick="showBox('aApp', 'app');">手机app</a>
		</div> -->
		<ul>
			<li>老板 , <?php echo ($date); ?> !</li>
			<li><a href="http://wpa.qq.com/msgrd?v=3&uin=869688800&site=qq&menu=yes" target="_blank" >人工客服</a></li>
			<li><a href="<?php echo U('/Login/logout');?>">退出</a></li>
		</ul>
</div>
<div class="brand">
		<a href="<?php echo U('/Index/index');?>" class="brand"><img src="/Public/Home/images/logo.jpg" alt=""></a>
</div><!-- 头部 -->
	<div class="sidebar">
		<ul class="sidebar-first">
			<li class="active"><a href="<?php echo U('/Index/index');?>">首页</a></li>
			<li><a href="<?php echo U('/Websites/index');?>">我的网站</a></li>
			<li><a href="<?php echo U('/Domains/domains');?>">我的域名</a></li>
			<li><a href="<?php echo U('/Cdservice/cdservice');?>">云狄服务</a></li>
			<li><a href="<?php echo U('/Orders/orders');?>">我的订单</a></li>
			<li><a href="<?php echo U('/Vip/vip');?>">会员中心</a></li>
			<li><a href="<?php echo U('/Carts/carts');?>">购物车</a></li>
		</ul>
</div><!-- 左边栏 -->
	<div class="container">


    <style>
    /*body{
  background-color:#ededf0; 
}*/
html{text-overflow:ellipsis;} /*解决IE6下图片抖动*/ 
div,form,img,ul,ol,li,dl,dt,dd,map {padding:0;margin:0;border:0;}
h1,h2,h3,h4,h5,h6 {margin:0; padding:0; }
body{margin:0px; padding:0px; font-size:14px; color:#666; font-family:"微软雅黑","宋体",Arial, Helvetica, sans-serif; background:#fff; min-width:1200px;}
img{ border:none;}
ul,li{ list-style:none;}
.clearfix:after{
  display: block;
  clear: both;
  height: 0;
  content: '';
  visibility: hidden;
}
div{
  display: block;
}

a{ color:#666; text-decoration:none;cursor: pointer;}
/*header*/
    *{
      padding: 0;
      margin: 0;
    }
   

.Top_t_1{
  background:url(images/back.png)no-repeat right center;
  width:60px;
    padding: 0px 11px;
    display: block;

}

.bus_pla{
  position: relative;
  line-height: 48px;
  font-size: 14px;
  margin-left: 15px;
    display: block;
    height: 49px;
    width: 109px;
    color: #ffffff;
    margin:0 auto;
    overflow: hidden; 
    background:url(../images/baise.png)no-repeat right center;
}
.ser_s{
  width:181px;
  height:240px;
    margin-top: 96px;

}
.ser_s>li{
background-color:#3598dc;
height: 48px;
width: 181px;

}
.ser_s li>a{
    font-size: 15px;
    color:#ffffff;
    line-height:40px;
    height: 40px;
    width:75px;
    float: left;
   margin-left:61px;
}

.Group_tab1{
  width:970px;
  height:728px;
  
  margin-top:26px;
  margin-left: 16px;   
}


.ser_s{
  width:181px;
  height:240px;
    margin-top: 96px;

}
.ser_s>li{
background-color:#3598dc;
height: 48px;
width: 181px;

}
.ser_s li>a{
    font-size: 15px;
    color:#ffffff;
    line-height:40px;
    height: 40px;
    width:75px;
    float: left;
   margin-left:61px;
}
.Group_btn_line{
  width:506px;
    margin-top:-1px; 
  background-color:#e5e5e5;
  height: 1px;
  float:right;   
}

body{
  background-color:#ededf0; 
}

.Group_box{
  float: left;
    width: 1138px;
  height: 542px;
  
  overflow: hidden;
  background-color: white;
}


#Group_item{
    width:970px;
    height:40px;
    margin-top:26px;
    margin-left: 21px; 
     }

     #Group_item>div{
      width:92px;
  height: 40px;
  text-align: center;
  color: #5c5c5c;
  line-height: 40px;
  float: left;
  border-left:1px solid #e5e5e5;
  border-bottom:1px solid #e5e5e5;
  border-top:1px solid #e5e5e5;
cursor: pointer;
     }
     #Group_item>div:nth-child(5){
         border-right: 1px solid #e5e5e5;
     }
#Group_item>.active{
  border-top:2px solid #3598dc;
  border-bottom: none;
}
     #Group_main{
    margin-left: -36px;
    height: auto;
    width: 100%;
    margin-top: 35px;
          
     }
     #Group_main>.active{
      display: block;
     }
     #Group_main>div{
      display: none;
     }
     #Group_main>div>a{
      width:28%;
      height:238px;
      
      float: left;
      margin-left: 5%;
      margin-bottom: 3%;  
     }
  </style>  	
 
     
                      
            <div class="Group_box">
       
             
    <div id="Group_item">
      <div class="active">服装</div>
      <div>饰品</div>
      <div>鞋帽箱包</div>
      <div>户外用品</div>
      <div>美容护肤</div>
     <?php $array = array(1,2,3,4,5); ?>
     <span class="Group_btn_line"></span>
    </div>
    <div id="Group_main">

	<?php if(is_array($array)): foreach($array as $key=>$v): ?><div class="active">
      <a href=""><img src="images/pic-1.jpg" /><?php echo ($v); ?></a>
      <a href=""><img src="images/pic-1.jpg" /></a>
      <a href=""><img src="images/pic-1.jpg" /></a>
      <a href=""><img src="images/pic-1.jpg" /></a>
      <a href=""><img src="images/pic-1.jpg" /></a>
      <a href=""><img src="images/pic-1.jpg" /></a>
      </div><?php endforeach; endif; ?>
    </div>
   

                 
           </div>
          <script type="text/javascript">
         var oGitem=document.getElementById('Group_item').getElementsByTagName('div');
         var oGmain=document.getElementById('Group_main').getElementsByTagName('div');
       for (var i = 0; i < oGitem.length; i++) {
        oGitem[i].index=i;

         console.log(oGitem[i].index);
        oGitem[i].onclick=function(){
          
          for (var i = 0; i < oGmain.length; i++) {
            oGmain[i].style.display='none';
            oGitem[i].style.borderTop='1px solid #e5e5e5';
            oGitem[i].style.borderBottom='1px solid #e5e5e5';
          }
           oGmain[this.index].style.display='block';
           oGitem[this.index].style.borderTop='2px solid #3598dc';
           oGitem[this.index].style.borderBottom='none';


        }



       }
    </script>

		<!-- <div class="content-tab web" id="index"  <?php echo ($user_classes?'':'style="display:none"'); ?> >
			首页广告
		</div>
		<div class="content-tab web" style="display:none"   id="web">
			<div class="content-tab-1 clearfix">
				<div class="content-tab-1-img">
					<p><img src="/Public/Home/images/bz.png" alt=""></p>
					<p>营销型网站</p>
				</div>
				<div class="content-tab-1-text">
					<p>会员价：<span class="cxj">398元</span>  <span class="yj">原价: 3800 元</span></p>
					<p><a href="" class="check">一年</a><a href="" class="check active">四年</a><a href="" class="check">十年</a></p>
					<p><a href="orders.html" class="action">立即购买</a><a href="carts.html" class="action">加入购物车</a>购买之后免费赠送四年会员 <a href="vip.html" style="color:#f60">会员特权</a></p>
				</div>
			</div>
			<div class="content-tab-1 clearfix">
				<div class="content-tab-1-img">
					<p><img src="images/bz.png" alt=""></p>
					<p>商城型网站</p>
				</div>
				<div class="content-tab-1-text">
					<p>促销价：<span class="cxj">798元</span>  <span class="yj">原价: 8800 元</span></p>
					<p><a href="" class="check active">一年</a><a href="" class="check">四年</a><a href="" class="check">十年</a></p>
					<p><a href="orders.html" class="action">立即购买</a><a href="carts.html" class="action">加入购物车</a>购买之后免费赠送一年VIP会员 <a href="vip.html" style="color:#f60">VIP会员特权</a></p>
				</div>
			</div>
		</div>
		<div class="content-tab domain" style="display:none"  id="domain">
			<p>
				<img src="/Public/Home/images/domain.png" alt="">
			</p>
		</div>
		<div class="content-tab weigw" style="display:none"  id="weigw">
			<p>
				微官网，未开通
			</p>
		</div>
		<div class="content-tab weifx" style="display:none"  id="weifx">
			<p>
				微分销，未开通
			</p>
		</div>
		<div class="content-tab h5" style="display:none"  id="h5">
			<p>
				H5宣传页，未开通
			</p>
		</div>
		<div class="content-tab app" style="display:none"  id="app">
			<p>
				手机app，未开通
			</p>
		</div>
		<div class="content-tab"  <?php echo ($user_classes?'style="display:none"':''); ?>  id="yxstyle">
			<p>
				<a href="<?php echo U('/Indexs/tpl_choose',array('id'=>2));?>">
				<img src="/Public/Home/images/yxstyle.png" alt="">
				</a>
			</p>
		</div>
		<div class="content-tab" style="display:none"  id="scstyle">
			<p>
				<a href="<?php echo U('/Indexs/tpl_choose',array('id'=>1));?>">
				<img src="/Public/Home/images/scstyle.png" alt="">
				</a>
			</p>
		</div> -->
	</div>
	<script src="//cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
	<script>
		function showBox(aitem, item){
			$('#' + aitem).addClass('active');
			$('#' + aitem).siblings('a').removeClass('active');
			$('#' + item).show();
			$('#' + item).siblings('div.content-tab').hide();
		}
	</script>
</body>
</html>