<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
  <title>增加栏目</title>
 	<meta charset="UTF-8">
	<link href="/Public/Home/css/normalize.min.css" rel="stylesheet">
	<link href="/Public/Home/css/user.css" rel="stylesheet">
	<link rel="shortcut icon" href="/Public/favicon.ico" type="image/x-icon" />
	<script type="text/javascript" src="/Public/Home/js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="/Public/Home/layer/layer.js"></script>
</head>
<body>
<div class="header">
		<div class="title-tab">
			<a href="javascript:;"  id="aScstyle" onclick="showBox('aScstyle', 'scstyle');">商城网站</a>
			<a href="javascript:;" <?php echo ($user_classes?'':'class="active"'); ?> id="aYxstyle" onclick="showBox('aYxstyle', 'yxstyle');">营销网站</a>
			<a href="javascript:;"  id="aDomain" onclick="showBox('aDomain', 'domain');">域名</a>
			<a href="javascript:;"  id="aWeigw" onclick="showBox('aWeigw', 'weigw');">微官网</a>
			<a href="javascript:;"  id="aWeifx" onclick="showBox('aWeifx', 'weifx');">微分销</a>
			<a href="javascript:;"  id="aH5" onclick="showBox('aH5', 'h5');">H5宣传页</a>
			<a href="javascript:;"  id="aApp" onclick="showBox('aApp', 'app');">手机app</a>
		</div>
		<ul>
			<li>老板 , <?php echo ($date); ?> !</li>
			<li><a href="http://wpa.qq.com/msgrd?v=3&uin=869688800&site=qq&menu=yes" target="_blank" >人工客服</a></li>
			<li><a href="<?php echo U('/Login/logout');?>">退出</a></li>
		</ul>
</div>
<div class="brand">
		<a href="<?php echo U('/Index/index');?>" class="brand"><img src="/Public/Home/images/logo.jpg" alt=""></a>
</div><!-- b头部 -->
 <div class="sidebar">
		<ul class="sidebar-first">
			<li class="active"><a href="<?php echo U('/Index/index');?>">首页</a></li>
			<li><a href="<?php echo U('/Websites/index');?>">我的网站</a></li>
			<li><a href="<?php echo U('/Domains/domains');?>">我的域名</a></li>
			<li><a href="<?php echo U('/Cdservice/cdservice');?>">云狄服务</a></li>
			<li><a href="<?php echo U('/Orders/orders');?>">我的订单</a></li>
			<li><a href="<?php echo U('/Vip/vip');?>">会员中心</a></li>
			<li><a href="<?php echo U('/Carts/carts');?>">购物车</a></li>
		</ul>
</div><!-- 左边栏 -->
  <div class="container">
  <style type="text/css">

#mynav li{

	width:100px;
	height:30px;
	float:left;
	margin-left: 10px;
	line-height: 30px;
}
#mynav li a{
	color:#fff;
}
</style>
<div style="width:100%;height:30px;background:#008CBA" id="mynav">
		<ul>
			<li><a href="<?php echo U('Websites/config');?>">网站配置</a></li>
			<li><a href="<?php echo U('Websites/column');?>">栏目管理</a></li>
			<li><a href="<?php echo U('Websites/article');?>">文章管理</a></li>
			<li><a href="<?php echo U('Websites/carousel');?>">轮播图管理</a></li>
			<li><a href="<?php echo U('Websites/friendship');?>">友链管理</a></li>
			<li><a href="<?php echo U('Message/message');?>">留言管理</a></li>
			<li><a href="http://<?php echo session('homeuser.name');?>.<?php echo session('domain');?>"  target="_blank">浏览我的网站</a></li>
		</ul>
</div><!-- 头部 -->
<style type="text/css">
input{
  width:90%;
}

table{
  text-align:left;
}

</style> 
<!-- 百度编辑器 -->
 <script type="text/javascript" charset="utf-8" src="/Public/Home/ueditor-utf8-php/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="/Public/Home/ueditor-utf8-php/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="/Public/Home/ueditor-utf8-php/lang/zh-cn/zh-cn.js"></script>
<!-- 百度编辑器 -->
<div style="margin-top:15%;margin-left:30%;width:100%;margin:0 auto;">
    <form method="post" action="<?php echo U('Websites/column_add');?>">
    <table>
     <tr>
        <td style="width:100px;">父级栏目:</td>
        <td>
          <select name="column_pid" style="width:90.5%;">
            <option value="0">增加顶级栏目</option>
            <?php if(is_array($father)): foreach($father as $key=>$vo): ?><option value="<?php echo ($vo['column_id']); ?>" 
              <?php if(($vo['column_id'] == $pid)): ?>selected<?php endif; ?>
              
              ><?php echo ($vo['column_name']); ?></option><?php endforeach; endif; ?>
          </select>
        </td>
    </tr>
    <tr>
        <td style="width:100px;">栏目名称:</td>
        <td><input type="type" name="column_name"/></td>

    </tr>
    <tr>
        <td style="width:100px;">栏目标题:</td>
        <td><input type="type" name="column_title"/></td>
    </tr>
    <tr>
        <td style="width:100px;">栏目关键词:</td>
        <td><input type="type" name="column_keywords"/></td>
    </tr>
    <tr>
        <td style="width:100px;">栏目描述:</td>
        <td><textarea name="column_description" style="width:90%;height:100px;"></textarea></td>
    </tr>
    <tr>
        <td style="width:100px;">栏目状态:</td>
        <td style="text-align:left;">
          <input name="column_status" type="radio" value="0" checked style="width:20px;" />显示
          <input name="column_status" type="radio" value="1" style="width:20px;" />隐藏
        </td>
    </tr>
    <tr>
        <td style="width:100px;">栏目类型:</td>
        <td style="text-align:left;">
          <input name="column_type" type="radio" value="products" checked style="width:20px;" />产品
          <input name="column_type" type="radio" value="newss" style="width:20px;" />资讯
          <input id="editors" name="column_type" type="radio" value="cover" style="width:20px;" />封面
        </td>
    </tr>
    <tr style="display:none;" id="treditors">
        <td style="width:100px;">栏目内容:</td>
        <td style="text-align:left;">
         <script id="editor" type="text/plain" style="width:100%;height:500px;" name="column_text"><?php echo ($column['column_text']); ?></script>
        </td>
    </tr>
   <tr style="text-align:center;" >
   <td colspan="2"><input type="submit" name="" value="添加" style="width:100px;margin-left:80px;"/></td>
   </tr>
    </table>
    </form>
</div>
</div>
</body>
<script>
var ue = UE.getEditor('editor');//创建百度编辑器

  $(":radio").click(function(){
    if($("#editors:radio").attr('checked')){
      $('#treditors').css('display','');
    }else{

      $('#treditors').css('display','none');
    }
  });


</script>
</html>