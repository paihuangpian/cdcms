<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
	<meta charset="UTF-8">
	<link href="/Public/Home/css/normalize.min.css" rel="stylesheet">
	<link href="/Public/Home/css/user.css" rel="stylesheet">
	<link rel="shortcut icon" href="/Public/favicon.ico" type="image/x-icon" />
	<script type="text/javascript" src="/Public/Home/js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="/Public/Home/layer/layer.js"></script>
</head>
<body>
<div class="header">
		<!-- <div class="title-tab">
			<a href="javascript:;"  id="aScstyle" onclick="showBox('aScstyle', 'scstyle');">商城网站</a>
			<a href="javascript:;" <?php echo ($user_classes?'':'class="active"'); ?> id="aYxstyle" onclick="showBox('aYxstyle', 'yxstyle');">营销网站</a>
			<a href="javascript:;"  id="aDomain" onclick="showBox('aDomain', 'domain');">域名</a>
			<a href="javascript:;"  id="aWeigw" onclick="showBox('aWeigw', 'weigw');">微官网</a>
			<a href="javascript:;"  id="aWeifx" onclick="showBox('aWeifx', 'weifx');">微分销</a>
			<a href="javascript:;"  id="aH5" onclick="showBox('aH5', 'h5');">H5宣传页</a>
			<a href="javascript:;"  id="aApp" onclick="showBox('aApp', 'app');">手机app</a>
		</div> -->
		<ul>
			<li>老板 , <?php echo ($date); ?> !</li>
			<li><a href="http://wpa.qq.com/msgrd?v=3&uin=869688800&site=qq&menu=yes" target="_blank" >人工客服</a></li>
			<li><a href="<?php echo U('/Login/logout');?>">退出</a></li>
		</ul>
</div>
<div class="brand">
		<a href="<?php echo U('/Index/index');?>" class="brand"><img src="/Public/Home/images/logo.jpg" alt=""></a>
</div><!-- b头部 -->
<div class="sidebar">
		<ul class="sidebar-first">
			<li class="active"><a href="<?php echo U('/Index/index');?>">首页</a></li>
			<li><a href="<?php echo U('/Websites/index');?>">我的网站</a></li>
			<li><a href="<?php echo U('/Domains/domains');?>">我的域名</a></li>
			<li><a href="<?php echo U('/Cdservice/cdservice');?>">云狄服务</a></li>
			<li><a href="<?php echo U('/Orders/orders');?>">我的订单</a></li>
			<li><a href="<?php echo U('/Vip/vip');?>">会员中心</a></li>
			<li><a href="<?php echo U('/Carts/carts');?>">购物车</a></li>
		</ul>
</div><!-- 左边栏 -->
<div class="container">
<style> #mynav #nav_a6{background:#006A98;}</style>
<style type="text/css">

#mynav li{

	width:100px;
	height:30px;
	float:left;
	margin-left: 10px;
	line-height: 30px;
	text-align: center;
}
#mynav  a{
	color:#fff;
}

</style>
<div style="width:100%;height:30px;background:#008CBA" id="mynav">
		<ul>
			<li id="nav_a1"><a  href="<?php echo U('Websites/config');?>">网站配置</a></li>
			<li id="nav_a2"><a  href="<?php echo U('Websites/column');?>">栏目管理</a></li>
			<li id="nav_a3"><a  href="<?php echo U('Websites/article');?>">文章管理</a></li>
			<li id="nav_a4"><a  href="<?php echo U('Websites/carousel');?>">轮播图管理</a></li>
			<li id="nav_a5"><a  href="<?php echo U('Websites/friendship');?>">友链管理</a></li>
			<li id="nav_a6"><a  href="<?php echo U('Message/message');?>">留言管理</a></li>
			<li id="nav_a7"><a  href="http://<?php echo session('homeuser.name');?>.<?php echo session('domain');?>"  target="_blank">浏览我的网站</a></li>
		</ul>
</div><!-- 头部 -->
<style> 
	table th, table td{ padding:0 0; text-indent: 0;text-align:center; }
</style>
<table>
	<tr>
			<td style="width:100px;">留言者姓名</td>
			<td style="width:100px;">留言者电话</td>
			<td style="width:150px;">留言者邮箱</td>
			<td style="width:100px;">留言者QQ</td>
			<td>留言页面</td>
			<td style="width:100px;">留言内容</td>
			<td style="width:160px;">留言时间</td>
			<td style="width:50px;">操作</td>
	</tr>
	<?php if(is_array($messages)): foreach($messages as $key=>$v): ?><tr id="tr<?php echo ($v['message_id']); ?>">
			<td><?php echo ($v['message_username']); ?></td>
			<td><?php echo ($v['message_tel']); ?></td>
			<td><?php echo ($v['message_email']); ?></td>
			<td><?php echo ($v['message_qq']); ?></td>
			<td><?php echo ($v['message_url']); ?></td>
			<td onmouseenter="mymouseenter(<?php echo ($v['message_id']); ?>)" onmouseleave="mymouseleave()">显示内容</td>
			<div style="display:none;" id="div<?php echo ($v['message_id']); ?>"><?php echo ($v['message_text']); ?></div>
			<td><?php echo ($v['message_addtime']); ?></td>
			<td><button onclick="mydelete(<?php echo ($v['message_id']); ?>)">删除</button></td>
	</tr><?php endforeach; endif; ?>
</table>
<div style="width:400px;height:300px;position:fixed;z-index:999;display:none;left:40%;top:30%;background:#C6C6C6;" id="displays"></div>
</div>
</body>
<script>
function mydelete(id){
	if(confirm('你确认要删除吗？')){
		$.post("<?php echo U('Message/message_delete');?>",{'id':id},function(res){
			if(res == 1){
				$('#tr' + id).remove();
			}else{
				alert('删除失败！');
			}
		})
	}
}
function mymouseenter(id)
{
	$('#displays').css('display','');
	$('#displays').html($('#div' + id).html());
}

function mymouseleave()
{
	$('#displays').css('display','none');
}
</script>
</html>