<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
	<meta charset="UTF-8">
	<link href="/Public/Home/css/normalize.min.css" rel="stylesheet">
	<link href="/Public/Home/css/user.css" rel="stylesheet">
	<link rel="shortcut icon" href="/Public/favicon.ico" type="image/x-icon" />
	<script type="text/javascript" src="/Public/Home/js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="/Public/Home/layer/layer.js"></script>
</head>
<body>
<div class="header">
		<div class="title-tab">
			<a href="javascript:;"  id="aScstyle" onclick="showBox('aScstyle', 'scstyle');">商城网站</a>
			<a href="javascript:;" <?php echo ($user_classes?'':'class="active"'); ?> id="aYxstyle" onclick="showBox('aYxstyle', 'yxstyle');">营销网站</a>
			<a href="javascript:;"  id="aDomain" onclick="showBox('aDomain', 'domain');">域名</a>
			<a href="javascript:;"  id="aWeigw" onclick="showBox('aWeigw', 'weigw');">微官网</a>
			<a href="javascript:;"  id="aWeifx" onclick="showBox('aWeifx', 'weifx');">微分销</a>
			<a href="javascript:;"  id="aH5" onclick="showBox('aH5', 'h5');">H5宣传页</a>
			<a href="javascript:;"  id="aApp" onclick="showBox('aApp', 'app');">手机app</a>
		</div>
		<ul>
			<li>老板 , <?php echo ($date); ?> !</li>
			<li><a href="http://wpa.qq.com/msgrd?v=3&uin=869688800&site=qq&menu=yes" target="_blank" >人工客服</a></li>
			<li><a href="<?php echo U('/Login/logout');?>">退出</a></li>
		</ul>
</div>
<div class="brand">
		<a href="<?php echo U('/Index/index');?>" class="brand"><img src="/Public/Home/images/logo.jpg" alt=""></a>
</div><!-- b头部 -->
<div class="sidebar">
		<ul class="sidebar-first">
			<li class="active"><a href="<?php echo U('/Index/index');?>">首页</a></li>
			<li><a href="<?php echo U('/Websites/index');?>">我的网站</a></li>
			<li><a href="<?php echo U('/Domains/domains');?>">我的域名</a></li>
			<li><a href="<?php echo U('/Cdservice/cdservice');?>">云狄服务</a></li>
			<li><a href="<?php echo U('/Orders/orders');?>">我的订单</a></li>
			<li><a href="<?php echo U('/Vip/vip');?>">会员中心</a></li>
			<li><a href="<?php echo U('/Carts/carts');?>">购物车</a></li>
		</ul>
</div><!-- 左边栏 -->
<div class="container">
<!-- 头部 -->
<style> 
	table th, table td{ padding:0 0; text-indent: 0;text-align:center; }
</style>
<table>
	<tr>
			<td style="width:100px;">留言者姓名</td>
			<td style="width:100px;">留言者电话</td>
			<td style="width:150px;">留言者邮箱</td>
			<td style="width:100px;">留言者QQ</td>
			<td>留言页面</td>
			<td>留言内容</td>
			<td style="width:160px;">留言时间</td>
			<td style="width:50px;">操作</td>
	</tr>
	<?php if(is_array($messages)): foreach($messages as $key=>$v): ?><tr id="tr<?php echo ($v['message_id']); ?>">
			<td><?php echo ($v['message_username']); ?></td>
			<td><?php echo ($v['message_tel']); ?></td>
			<td><?php echo ($v['message_email']); ?></td>
			<td><?php echo ($v['message_qq']); ?></td>
			<td><?php echo ($v['message_url']); ?></td>
			<td><?php echo ($v['message_text']); ?></td>
			<td><?php echo ($v['message_addtime']); ?></td>
			<td><button onclick="mydelete(<?php echo ($v['message_id']); ?>)">删除</button></td>
	</tr><?php endforeach; endif; ?>
</table>
</div>
</body>
<script>
function mydelete(id){
	$.post("Message/message_delete",{'id':id},function(res){
		if(res == 1){
			$('#tr' + id).remove();
		}else{
			alert('删除失败！');
		}
	})
}
</script>
</html>