<?php
namespace Home\Controller;
use Think\Controller;
class DomainsController extends CommonController 
{
    public function index()
    {

    	echo 1;
    	// $this->display();
    }


    /**
     * 模板选择
     */
    public function tpl_choose()
    {
    	

        echo '模板选择';
    }


}